// services.js - loads the full service menu into the grid.

function serviceCardHTML(service) {
  const price = (service.price_cents / 100).toFixed(2);
  return `
    <div class="card${service.is_signature ? ' card-signature' : ''}">
      ${service.is_signature ? '<span class="card-signature-label">Signature Treatment</span>' : ''}
      <h3>${service.name}</h3>
      <p>${service.description}</p>
      <div class="card-meta">
        <span>${service.duration_minutes} min</span>
        <span>$${price}</span>
      </div>
      <a href="book.html?service=${service.id}" class="btn btn-outline">Book This</a>
    </div>
  `;
}

async function loadAllServices() {
  const grid = document.getElementById('services-list');
  try {
    const services = await SerenityAPI.getServices();
    grid.innerHTML = services.map(serviceCardHTML).join('');
  } catch (err) {
    grid.innerHTML = '<p>Unable to load services right now. Please try again shortly.</p>';
  }
}

document.addEventListener('DOMContentLoaded', loadAllServices);
