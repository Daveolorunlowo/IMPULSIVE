// home.js - loads the top 3 services into the "Popular Treatments" grid.

function serviceCardHTML(service) {
  const price = (service.price_cents / 100).toFixed(2);
  return `
    <div class="card${service.is_signature ? ' card-signature' : ''}">
      ${service.is_signature ? '<span class="card-signature-label">Signature Treatment</span>' : ''}
      <h3>${service.name}</h3>
      <p>${service.description}</p>
      <div class="card-meta">
        <span>${service.duration_minutes} min</span>
        <span>$${price}</span>
      </div>
      <a href="book.html?service=${service.id}" class="btn btn-outline">Book This</a>
    </div>
  `;
}

async function loadPopularServices() {
  const grid = document.getElementById('popular-services');
  try {
    const services = await SerenityAPI.getServices();
    grid.innerHTML = services.slice(0, 3).map(serviceCardHTML).join('');
  } catch (err) {
    grid.innerHTML = '<p>Unable to load services right now. Please try again shortly.</p>';
  }
}

document.addEventListener('DOMContentLoaded', loadPopularServices);
