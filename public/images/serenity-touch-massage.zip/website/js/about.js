// about.js - loads therapist names and bios into the team grid.

function staffCardHTML(member) {
  return `
    <div class="card">
      <h3>${member.name}</h3>
      <p>${member.bio}</p>
    </div>
  `;
}

async function loadTeam() {
  const grid = document.getElementById('staff-list');
  try {
    const staff = await SerenityAPI.getStaff();
    grid.innerHTML = staff.map(staffCardHTML).join('');
  } catch (err) {
    grid.innerHTML = '<p>Unable to load our team right now. Please try again shortly.</p>';
  }
}

document.addEventListener('DOMContentLoaded', loadTeam);
