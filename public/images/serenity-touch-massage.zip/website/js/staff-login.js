// staff-login.js - username + password only (no OTP step, per client spec).
// On success, stores the session token in sessionStorage and redirects to
// the dashboard. sessionStorage clears when the browser tab closes.

async function handleLogin(e) {
  e.preventDefault();
  const errorEl = document.getElementById('form-error');
  errorEl.hidden = true;

  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const submitBtn = document.getElementById('submit-btn');
  submitBtn.disabled = true;
  submitBtn.textContent = 'Logging in…';

  try {
    const { token, name } = await SerenityAPI.staffLogin(username, password);
    sessionStorage.setItem('staffToken', token);
    sessionStorage.setItem('staffName', name);
    window.location.href = 'staff-dashboard.html';
  } catch (err) {
    errorEl.textContent = 'Invalid username or password.';
    errorEl.hidden = false;
    submitBtn.disabled = false;
    submitBtn.textContent = 'Log In';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('login-form').addEventListener('submit', handleLogin);
});
