// staff-dashboard.js - loads bookings for the logged-in therapist/staff
// member and lets them update a booking's status.

const STATUS_OPTIONS = ['pending_payment', 'confirmed', 'completed', 'cancelled'];

function statusSelectHTML(booking) {
  return `
    <select data-booking-id="${booking.id}" class="status-select">
      ${STATUS_OPTIONS.map(
        (s) => `<option value="${s}" ${s === booking.status ? 'selected' : ''}>${s.replace('_', ' ')}</option>`
      ).join('')}
    </select>
  `;
}

function bookingRowHTML(booking) {
  const when = new Date(booking.appointment_time).toLocaleString();
  return `
    <tr>
      <td>${when}</td>
      <td>${booking.customer_name}<br /><small>${booking.customer_email}</small></td>
      <td>${booking.service_name}</td>
      <td>${booking.staff_name || 'Any'}</td>
      <td>${booking.status}</td>
      <td>${statusSelectHTML(booking)}</td>
    </tr>
  `;
}

async function loadBookings(token) {
  const tbody = document.getElementById('bookings-body');
  try {
    const bookings = await SerenityAPI.getStaffBookings(token);
    tbody.innerHTML = bookings.length
      ? bookings.map(bookingRowHTML).join('')
      : '<tr><td colspan="6">No bookings yet.</td></tr>';

    tbody.querySelectorAll('.status-select').forEach((select) => {
      select.addEventListener('change', async (e) => {
        const bookingId = e.target.getAttribute('data-booking-id');
        await SerenityAPI.updateBookingStatus(token, bookingId, e.target.value);
      });
    });
  } catch (err) {
    const errorEl = document.getElementById('form-error');
    errorEl.textContent = 'Your session expired. Please log in again.';
    errorEl.hidden = false;
    setTimeout(() => { window.location.href = 'staff-login.html'; }, 1500);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const token = sessionStorage.getItem('staffToken');
  if (!token) {
    window.location.href = 'staff-login.html';
    return;
  }
  loadBookings(token);

  document.getElementById('logout-btn').addEventListener('click', () => {
    sessionStorage.removeItem('staffToken');
    sessionStorage.removeItem('staffName');
    window.location.href = 'staff-login.html';
  });
});
