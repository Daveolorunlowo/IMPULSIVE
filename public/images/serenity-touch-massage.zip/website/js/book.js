// book.js - populates the service/therapist dropdowns, then on submit creates
// a pending booking and redirects to Stripe Checkout to collect payment.

function getQueryParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}

async function populateServices() {
  const select = document.getElementById('service_id');
  const preselectId = getQueryParam('service');
  try {
    const services = await SerenityAPI.getServices();
    select.innerHTML =
      '<option value="">Select a service&hellip;</option>' +
      services
        .map((s) => {
          const price = (s.price_cents / 100).toFixed(2);
          const selected = preselectId && String(s.id) === preselectId ? 'selected' : '';
          return `<option value="${s.id}" ${selected}>${s.name} &mdash; ${s.duration_minutes} min &mdash; $${price}</option>`;
        })
        .join('');
  } catch (err) {
    select.innerHTML = '<option value="">Unable to load services</option>';
  }
}

async function populateStaff() {
  const select = document.getElementById('staff_id');
  try {
    const staff = await SerenityAPI.getStaff();
    select.innerHTML =
      '<option value="">No preference</option>' +
      staff.map((m) => `<option value="${m.id}">${m.name}</option>`).join('');
  } catch (err) {
    // Non-critical - "No preference" still works if this fails.
  }
}

function showError(message) {
  const errorEl = document.getElementById('form-error');
  errorEl.textContent = message;
  errorEl.hidden = false;
}

async function handleSubmit(e) {
  e.preventDefault();
  const errorEl = document.getElementById('form-error');
  errorEl.hidden = true;

  const service_id = document.getElementById('service_id').value;
  const staff_id = document.getElementById('staff_id').value;
  const appointment_date = document.getElementById('appointment_date').value;
  const appointment_time = document.getElementById('appointment_time').value;
  const customer_name = document.getElementById('customer_name').value;
  const customer_email = document.getElementById('customer_email').value;
  const customer_phone = document.getElementById('customer_phone').value;

  if (!service_id || !appointment_date || !appointment_time || !customer_name || !customer_email) {
    showError('Please fill in all required fields.');
    return;
  }

  const submitBtn = document.getElementById('submit-btn');
  submitBtn.disabled = true;
  submitBtn.textContent = 'Redirecting to payment…';

  try {
    const { bookingId } = await SerenityAPI.createBooking({
      service_id: Number(service_id),
      staff_id: staff_id ? Number(staff_id) : null,
      customer_name,
      customer_email,
      customer_phone,
      appointment_time: `${appointment_date}T${appointment_time}`,
    });
    const { url } = await SerenityAPI.createCheckoutSession(bookingId);
    window.location.href = url; // Stripe's secure hosted checkout
  } catch (err) {
    showError(err.message || 'Something went wrong. Please try again.');
    submitBtn.disabled = false;
    submitBtn.textContent = 'Continue to Payment';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  populateServices();
  populateStaff();
  document.getElementById('booking-form').addEventListener('submit', handleSubmit);
});
