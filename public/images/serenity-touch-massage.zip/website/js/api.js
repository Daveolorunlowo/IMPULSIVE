// api.js - shared API client for the static site.
// Loaded on every page BEFORE that page's own script (see the <script> tags
// at the bottom of each .html file). Defines a global `SerenityAPI` object.

// Update this when you deploy the backend somewhere other than localhost.
const API_BASE = 'http://localhost:4000/api';

async function apiRequest(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({ error: 'Request failed' }));
    throw new Error(body.error || 'Request failed');
  }
  return res.json();
}

const SerenityAPI = {
  getServices: () => apiRequest('/services'),
  getStaff: () => apiRequest('/staff'),
  createBooking: (data) => apiRequest('/bookings', { method: 'POST', body: JSON.stringify(data) }),
  createCheckoutSession: (bookingId) =>
    apiRequest('/payments/create-checkout-session', { method: 'POST', body: JSON.stringify({ bookingId }) }),
  staffLogin: (username, password) =>
    apiRequest('/staff/login', { method: 'POST', body: JSON.stringify({ username, password }) }),
  getStaffBookings: (token) =>
    apiRequest('/staff/bookings', { headers: { Authorization: `Bearer ${token}` } }),
  updateBookingStatus: (token, id, status) =>
    apiRequest(`/staff/bookings/${id}`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${token}` },
      body: JSON.stringify({ status }),
    }),
};
