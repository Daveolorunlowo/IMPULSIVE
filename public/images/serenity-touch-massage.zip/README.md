# Serenity Touch Massage — Website

Two parts, run separately:

- **backend/** — Node/Express API: services, bookings, staff login, Stripe payments (SQLite database)
- **website/** — plain HTML/CSS/JS pages (home.html, services.html, about.html, contact.html, book.html, staff-login.html, staff-dashboard.html)

## 1. Run the backend

```
cd backend
npm install
cp .env.example .env
```

Edit `.env`:
- `JWT_SECRET` — any long random string
- `STRIPE_SECRET_KEY` — from https://dashboard.stripe.com/apikeys (use the **test** key first)
- `STRIPE_WEBHOOK_SECRET` — see step 3 below

```
npm run seed    # loads sample services + 2 staff logins (username maya / daniel, password ChangeMe123!)
npm start       # runs on http://localhost:4000
```

## 2. Run the website

The `website/` folder is plain static files — no build step. Easiest way to serve it locally:

```
cd website
npx serve .
```

Then open the URL it prints (e.g. `http://localhost:3000/home.html`).

If you open the HTML files directly by double-clicking them (`file://`), the pages will load but API calls may be blocked by the browser — serving them (as above) avoids that.

## 3. Connect Stripe webhooks (local testing)

Stripe needs to notify your backend when a payment succeeds. Locally, use the Stripe CLI:

```
stripe listen --forward-to localhost:4000/api/payments/webhook
```

It prints a `whsec_...` value — put that in `backend/.env` as `STRIPE_WEBHOOK_SECRET`, then restart the backend.

## 4. Before going live

- Replace the placeholder business name/address/phone/hours in every HTML file's footer and the Contact page
- Replace the two seeded staff accounts with real staff, real passwords
- Switch `STRIPE_SECRET_KEY` to your **live** key and re-point the webhook at your real domain
- Update `API_BASE` in `website/js/api.js` to your deployed backend URL
- See the roadmap PDF for the full pre-launch checklist
