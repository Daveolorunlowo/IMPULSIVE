import { Router } from 'express';
import db from '../db.js';

const router = Router();

// Creates a pending booking before payment. Stripe confirms it via webhook
// once the customer actually pays - see routes/payments.js.
router.post('/', (req, res) => {
  const { service_id, staff_id, customer_name, customer_email, customer_phone, appointment_time } = req.body;

  if (!service_id || !customer_name || !customer_email || !appointment_time) {
    return res.status(400).json({ error: 'Missing required booking details' });
  }

  const service = db.prepare('SELECT * FROM services WHERE id = ?').get(service_id);
  if (!service) return res.status(404).json({ error: 'Service not found' });

  const result = db.prepare(`
    INSERT INTO bookings (service_id, staff_id, customer_name, customer_email, customer_phone, appointment_time, status)
    VALUES (?, ?, ?, ?, ?, ?, 'pending_payment')
  `).run(service_id, staff_id || null, customer_name, customer_email, customer_phone || null, appointment_time);

  res.json({ bookingId: result.lastInsertRowid });
});

export default router;
