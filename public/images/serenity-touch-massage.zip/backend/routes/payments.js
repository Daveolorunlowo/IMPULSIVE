import { Router } from 'express';
import Stripe from 'stripe';
import db from '../db.js';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
const router = Router();

// Creates a Stripe Checkout session for a pending booking. Checkout is Stripe's
// hosted payment page - card details never touch our server, and enabling
// Apple Pay / Google Pay / Afterpay / etc. in the Stripe Dashboard makes them
// show up here automatically, with no extra integration code.
router.post('/create-checkout-session', async (req, res) => {
  const { bookingId } = req.body;
  const booking = db.prepare(`
    SELECT bookings.*, services.name as service_name, services.price_cents
    FROM bookings JOIN services ON bookings.service_id = services.id
    WHERE bookings.id = ?
  `).get(bookingId);

  if (!booking) return res.status(404).json({ error: 'Booking not found' });

  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'],
      customer_email: booking.customer_email,
      line_items: [{
        price_data: {
          currency: 'usd',
          product_data: { name: booking.service_name },
          unit_amount: booking.price_cents,
        },
        quantity: 1,
      }],
      metadata: { bookingId: String(booking.id) },
      success_url: `${process.env.FRONTEND_URL}/booking/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL}/booking/cancel`,
    });

    db.prepare('UPDATE bookings SET stripe_session_id = ? WHERE id = ?').run(session.id, booking.id);
    res.json({ url: session.url });
  } catch (err) {
    console.error('Stripe checkout error:', err.message);
    res.status(500).json({ error: 'Unable to start checkout' });
  }
});

// Stripe calls this server-to-server after payment completes. Confirming the
// booking here (rather than trusting the browser redirect) means a customer
// can't mark their own booking "paid" without actually paying.
export async function webhookHandler(req, res) {
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const bookingId = session.metadata.bookingId;
    db.prepare("UPDATE bookings SET status = 'confirmed' WHERE id = ?").run(bookingId);
  }

  res.json({ received: true });
}

export default router;
