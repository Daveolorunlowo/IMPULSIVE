import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import db from '../db.js';
import { requireStaffAuth } from '../middleware/auth.js';

const router = Router();

// Public: therapist names/bios for the booking page. Never exposes credentials.
router.get('/', (req, res) => {
  const staff = db.prepare('SELECT id, name, bio FROM staff').all();
  res.json(staff);
});

// Staff login - username + password only, no OTP step, as requested.
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }
  const staffMember = db.prepare('SELECT * FROM staff WHERE username = ?').get(username);
  if (!staffMember || !bcrypt.compareSync(password, staffMember.password_hash)) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  const token = jwt.sign(
    { id: staffMember.id, name: staffMember.name, username: staffMember.username },
    process.env.JWT_SECRET,
    { expiresIn: '12h' }
  );
  res.json({ token, name: staffMember.name });
});

// Protected: bookings list for the staff dashboard
router.get('/bookings', requireStaffAuth, (req, res) => {
  const bookings = db.prepare(`
    SELECT bookings.*, services.name as service_name, staff.name as staff_name
    FROM bookings
    LEFT JOIN services ON bookings.service_id = services.id
    LEFT JOIN staff ON bookings.staff_id = staff.id
    ORDER BY appointment_time ASC
  `).all();
  res.json(bookings);
});

// Protected: update a booking's status (confirm, complete, cancel)
router.patch('/bookings/:id', requireStaffAuth, (req, res) => {
  const { status } = req.body;
  const allowed = ['pending_payment', 'confirmed', 'completed', 'cancelled'];
  if (!allowed.includes(status)) {
    return res.status(400).json({ error: 'Invalid status' });
  }
  db.prepare('UPDATE bookings SET status = ? WHERE id = ?').run(status, req.params.id);
  res.json({ success: true });
});

export default router;
