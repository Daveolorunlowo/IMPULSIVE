import { Router } from 'express';
import db from '../db.js';

const router = Router();

router.get('/', (req, res) => {
  const services = db.prepare('SELECT * FROM services ORDER BY is_signature DESC, name').all();
  res.json(services);
});

export default router;
