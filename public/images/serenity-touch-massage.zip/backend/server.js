import express from 'express';
import cors from 'cors';
import 'dotenv/config';

import servicesRouter from './routes/services.js';
import staffRouter from './routes/staff.js';
import bookingsRouter from './routes/bookings.js';
import paymentsRouter, { webhookHandler } from './routes/payments.js';

const app = express();

app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:5173' }));

// Stripe needs the raw, unparsed request body to verify the webhook signature,
// so this route is registered BEFORE the global JSON body parser below.
app.post('/api/payments/webhook', express.raw({ type: 'application/json' }), webhookHandler);

app.use(express.json());

app.use('/api/services', servicesRouter);
app.use('/api/staff', staffRouter);
app.use('/api/bookings', bookingsRouter);
app.use('/api/payments', paymentsRouter);

app.get('/api/health', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Serenity Touch API running on http://localhost:${PORT}`));
