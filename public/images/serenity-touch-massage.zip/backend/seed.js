// Populates sample services and one staff login per therapist.
// Safe to re-run - it only inserts if the tables are empty.
import bcrypt from 'bcryptjs';
import db from './db.js';

const services = [
  ['Swedish Massage', 'A gentle, full-body massage that eases tension and improves circulation.', 60, 9000, 0],
  ['Deep Tissue Massage', 'Firm, targeted pressure to release chronic muscle tension and knots.', 60, 10500, 0],
  ['Hot Stone Massage', 'Warm basalt stones combined with massage to melt away stress.', 75, 12500, 1],
  ['Sports Massage', 'Focused on injury prevention and recovery for active clients.', 60, 11000, 0],
  ['Prenatal Massage', 'A soothing, safe massage tailored for expectant mothers.', 60, 10000, 0],
  ['Aromatherapy Massage', 'A relaxing massage enhanced with an essential oil blend of your choice.', 60, 10000, 0],
  ['Reflexology', 'Pressure-point therapy focused on the feet to promote whole-body ease.', 45, 7500, 0],
  ['Couples Massage', 'A side-by-side massage for two in our private couples suite.', 60, 19000, 0],
];

const existingServices = db.prepare('SELECT COUNT(*) as count FROM services').get();
if (existingServices.count === 0) {
  const insertService = db.prepare(
    'INSERT INTO services (name, description, duration_minutes, price_cents, is_signature) VALUES (?, ?, ?, ?, ?)'
  );
  for (const s of services) insertService.run(...s);
  console.log(`Seeded ${services.length} services.`);
}

const staff = [
  ['Maya Reynolds', 'Licensed Massage Therapist, 8 years experience. Specializes in deep tissue and sports recovery.', 'maya', 'ChangeMe123!'],
  ['Daniel Osei', 'Licensed Massage Therapist focused on Swedish and hot stone technique.', 'daniel', 'ChangeMe123!'],
];

const existingStaff = db.prepare('SELECT COUNT(*) as count FROM staff').get();
if (existingStaff.count === 0) {
  const insertStaff = db.prepare(
    'INSERT INTO staff (name, bio, username, password_hash) VALUES (?, ?, ?, ?)'
  );
  for (const [name, bio, username, plainPassword] of staff) {
    insertStaff.run(name, bio, username, bcrypt.hashSync(plainPassword, 10));
  }
  console.log(`Seeded ${staff.length} staff accounts. Default password is "ChangeMe123!" - change it before going live.`);
}
